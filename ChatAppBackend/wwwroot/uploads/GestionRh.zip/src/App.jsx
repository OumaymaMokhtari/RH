import React from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import LeaveRequestForm from "./components/LeaveRequestForm";
import LeaveList from "./components/LeaveList";
import "./style.css"; 

const App = () => {
    return (
        <Router>
            <div className="d-flex">
                {/* Sidebar */}
                <nav className="sidebar">
                    <ul className="nav flex-column">
                        <li className="nav-item"><Link className="nav-link" to="/">Accueil</Link></li>
                        <li className="nav-item"><Link className="nav-link" to="/demande">Congé</Link></li>
                        <li className="nav-item"><Link className="nav-link" to="/liste">Liste des congés</Link></li>
                        <li className="nav-item"><Link className="nav-link" to="#">Absence</Link></li>
                        

                    </ul>
                </nav>

                {/* Contenu principal */}
                <div className="content">
                    <Routes>
                        <Route path="/" element={<h1>Bienvenue dans Gestion Congés</h1>} />
                        <Route path="/demande" element={<LeaveRequestForm />} />
                        <Route path="/liste" element={<LeaveList />} />
                    </Routes>
                </div>
            </div>
        </Router>
    );
};

export default App;
