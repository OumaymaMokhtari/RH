import React, { useState, useEffect, useRef } from "react";
import * as signalR from "@microsoft/signalr";
import ObjectId from "bson-objectid";
import axios from "axios";  // 🔹 Import manquant ajouté
import "./styles.css";

const ChatWindow = ({ selectedEmployee }) => {
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState("");
  const [connection, setConnection] = useState(null);
  const currentUserId = localStorage.getItem("userId");
  const messagesEndRef = useRef(null);

  useEffect(() => {
    if (!selectedEmployee || !currentUserId) return;
    fetch(`http://localhost:5287/api/message/messages/${currentUserId}/${selectedEmployee.id}`)
      .then(response => response.json())
      .then(data => setMessages(data))
      .catch(error => console.error("Erreur lors de la récupération des messages :", error));
  }, [selectedEmployee, currentUserId]);

  useEffect(() => {
    if (!selectedEmployee || !currentUserId) return;
    const connect = new signalR.HubConnectionBuilder()
      .withUrl(`http://localhost:5287/chatHub?userId=${currentUserId}`, {
        transport: signalR.HttpTransportType.WebSockets
      })
      .withAutomaticReconnect()
      .configureLogging(signalR.LogLevel.Information)
      .build();

    connect.start()
      .then(() => {
        setConnection(connect);
        console.log("SignalR connecté avec succès !");
      })
      .catch(error => console.error("Erreur de connexion SignalR :", error));

    const handleMessageReceived = (senderId, receiverId, content, timestamp) => {
      setMessages(prevMessages => {
        if (!prevMessages.some(msg => msg.content === content && msg.senderId === senderId && msg.timestamp === timestamp)) {
          return [...prevMessages, { senderId, receiverId, content, timestamp }];
        }
        return prevMessages;
      });
    };

    connect.on("ReceiveMessage", handleMessageReceived);

    return () => {
      connect.off("ReceiveMessage", handleMessageReceived);
      if (connect && connect.state === "Connected") {
        connect.stop()
          .then(() => console.log("Connexion SignalR fermée."))
          .catch(err => console.error("Erreur lors de la fermeture de SignalR :", err));
      }
    };
  }, [selectedEmployee, currentUserId]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const sendMessage = async () => {
    if (!currentUserId || !selectedEmployee || newMessage.trim() === "") {
      console.error("Erreur: senderId ou receiverId manquant");
      return;
    }
    const message = {
      id: ObjectId().toString(),
      senderId: currentUserId,
      receiverId: selectedEmployee.id,
      content: newMessage.trim(),
      timestamp: new Date().toISOString(),
    };
    setNewMessage("");
    if (connection && connection.state === "Connected") {
      await connection.invoke("SendMessage", message.senderId, message.receiverId, message.content)
        .catch(err => console.error("Erreur d'envoi via SignalR :", err));
    } else {
      console.error("SignalR non connecté !");
    }
  };

  const handleFileChange = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const formData = new FormData();
    formData.append("file", file);

    try {
      const response = await axios.post("http://localhost:5287/api/File/upload", formData);
      const fileUrl = response.data.fileUrl;

      if (connection && connection.state === "Connected") {
        await connection.invoke("SendMessage", currentUserId, selectedEmployee.id, fileUrl)
          .catch(err => console.error("Erreur d'envoi du fichier via SignalR :", err));
      } else {
        console.error("SignalR non connecté !");
      }

    } catch (error) {
      console.error("Erreur lors de l'upload du fichier", error);
    }
  };

  return (
    <div className="chat-window">
      <div className="chat-header">
        <h2>{selectedEmployee ? selectedEmployee.name : "Aucun utilisateur sélectionné"}</h2>
      </div>
      <div className="message-container">
    {messages.map((msg, index) => (
        <React.Fragment key={msg.id || index}>
            {/* Afficher la date une seule fois par jour */}
            {index === 0 || new Date(messages[index - 1].timestamp).toLocaleDateString() !== new Date(msg.timestamp).toLocaleDateString() ? (
                <div className="date-separator">
                    {new Date(msg.timestamp).toLocaleDateString()}
                </div>
            ) : null}

            {/* Affichage du message */}
            <div className={`message ${msg.senderId === currentUserId ? "sent" : "received"}`}>
                {msg.content.includes("http") ? (
                    <a href={msg.content} target="_blank" rel="noopener noreferrer">
                        Télécharger le fichier
                    </a>
                ) : (
                    <p>{msg.content}</p>
                )}
                <span className="timestamp">
                    {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
            </div>
        </React.Fragment>
    ))}

    <div ref={messagesEndRef}></div>
</div>

      <div className="input-container">
      <input type="file" onChange={handleFileChange} className="file-input" />
        <input className="input-message" value={newMessage} onChange={(e) => setNewMessage(e.target.value)} placeholder="Taper votre message..."/>
        <button className="send-button" onClick={sendMessage}>Envoyer</button>
      </div>
      
    </div>
  );
};

export default ChatWindow;
