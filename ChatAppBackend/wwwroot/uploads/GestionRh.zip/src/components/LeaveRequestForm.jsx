import React, { useState, useEffect } from "react";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { createConge, calculateLeaveDuration } from "../services/api";

const LeaveRequestForm = () => {
    const [startDate, setStartDate] = useState(null);
    const [endDate, setEndDate] = useState(null);
    const [duration, setDuration] = useState(0);
    const [type, setType] = useState("");
    const [comment, setComment] = useState("");

    const calculateDuration = () => {
        if (startDate && endDate) {
            const diff = (endDate - startDate) / (1000 * 60 * 60 * 24);
            return diff + 1; 
        }
        return 0;
    };

    useEffect(() => {
        if (startDate && endDate) {
            calculateLeaveDuration(startDate, endDate).then(setDuration);
        }
    }, [startDate, endDate]);

    const handleSubmit = async (e) => {
        e.preventDefault();

        const newConge = {
            employeId: 1,
            dateDebut: startDate,
            dateFin: endDate,
            typeConge: type,
            commentaire: comment,
        };

        console.log("Données envoyées :", JSON.stringify(newConge, null, 2));

        try {
            await createConge(newConge);
            alert("Demande envoyée !");
        } catch (error) {
            console.error("Erreur lors de l'envoi :", error.response ? error.response.data : error.message);
            alert("Erreur lors de la demande de congé.");
        }
    };

    return (
        <div className="container">
            <h2 className="mt-4">Demander un congé</h2>
            <form className="mt-3" onSubmit={handleSubmit}>
                <div className="mb-3">
                    <label className="form-label">Date de début :</label>
                    <DatePicker selected={startDate} onChange={(date) => setStartDate(date)} className="form-control" />
                </div>

                <div className="mb-3">
                    <label className="form-label">Date de fin :</label>
                    <DatePicker selected={endDate} onChange={(date) => setEndDate(date)} className="form-control" />
                </div>

                <div className="mb-3">
                    <label className="form-label">Durée :</label>
                    <input type="text" className="form-control" value={duration} readOnly />
                </div>

                <div className="mb-3">
                    <label className="form-label">Type de congé :</label>
                    <select className="form-control" onChange={(e) => setType(e.target.value)}>
                        <option value="">Sélectionner</option>
                        <option value="Annuel">Annuel</option>
                        <option value="Maladie">Maladie</option>
                        <option value="Sans solde">Sans solde</option>
                    </select>
                </div>

                <div className="mb-3">
                    <label className="form-label">Commentaire :</label>
                    <textarea className="form-control" onChange={(e) => setComment(e.target.value)} />
                </div>

                <button type="submit" className="btn btn-primary">Soumettre</button>
            </form>
        </div>
    );
};

export default LeaveRequestForm;
